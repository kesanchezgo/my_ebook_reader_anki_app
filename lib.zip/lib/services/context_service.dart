enum ContextMode {
  sentence,
  paragraph,
}

class ContextService {
  /// Extrae el contexto (oración o párrafo) alrededor de una palabra seleccionada.
  String extractContext({
    required String word,
    required String fullText,
    ContextMode mode = ContextMode.sentence,
    double? scrollPercentage,
  }) {
    if (word.isEmpty || fullText.isEmpty) return "";

    final escapedWord = RegExp.escape(word);
    // Búsqueda case-insensitive
    final List<RegExpMatch> matches = RegExp(
      r'\b' + escapedWord + r'\b',
      caseSensitive: false,
    ).allMatches(fullText).toList();

    if (matches.isEmpty) return "";

    RegExpMatch bestMatch = matches.first;

    if (scrollPercentage != null) {
      bestMatch = _findMatchByScrollImproved(
        fullText: fullText,
        matches: matches,
        scrollPercentage: scrollPercentage,
      );
    }

    return _expandBoundaries(fullText, bestMatch.start, bestMatch.end, mode);
  }

  /// Encuentra el mejor match usando ventana de búsqueda y scoring con sesgo adelante
  RegExpMatch _findMatchByScrollImproved({
    required String fullText,
    required List<RegExpMatch> matches,
    required double scrollPercentage,
  }) {
    final clampedScroll = scrollPercentage.clamp(0.0, 1.0);
    final docLength = fullText.length;
    final centerPos = (docLength * clampedScroll).round();

    // Definir ventana de búsqueda (±10% del documento)
    final windowSize = (docLength * 0.10).round();
    final windowStart = (centerPos - windowSize).clamp(0, docLength);
    final windowEnd = (centerPos + windowSize).clamp(0, docLength);

    // Filtrar matches dentro de la ventana
    final matchesInWindow = matches
        .where((match) => match.start >= windowStart && match.start <= windowEnd)
        .toList();

    if (matchesInWindow.isEmpty) {
      // Fallback: buscar el más cercano de todos
      return _findClosestMatch(matches, centerPos);
    }

    // De los matches en la ventana, elegir usando scoring con sesgo adelante
    RegExpMatch? bestMatch;
    double bestScore = double.infinity;

    for (final match in matchesInWindow) {
      final distance = (match.start - centerPos).abs().toDouble();

      // Sesgo hacia adelante: 30% de descuento para matches futuros
      final score = match.start >= centerPos
          ? distance * 0.7 // Matches adelante son preferidos
          : distance * 1.0; // Matches atrás sin descuento

      if (score < bestScore) {
        bestScore = score;
        bestMatch = match;
      }
    }

    return bestMatch ?? matches.first;
  }

  /// Busca el match más cercano a una posición (fallback)
  RegExpMatch _findClosestMatch(List<RegExpMatch> matches, int targetPosition) {
    RegExpMatch closest = matches.first;
    double minDistance = (matches.first.start - targetPosition).abs().toDouble();

    for (final match in matches) {
      final distance = (match.start - targetPosition).abs().toDouble();
      if (distance < minDistance) {
        minDistance = distance;
        closest = match;
      }
    }

    return closest;
  }

  String _expandBoundaries(
      String fullText, int wordIndex, int wordEnd, ContextMode mode) {
    // Definir delimitadores según el modo
    final RegExp delimiters = mode == ContextMode.sentence
        ? RegExp(r'[.?!。！？\n]') // Fin de oración
        : RegExp(r'[\n\r]'); // Fin de párrafo

    // Expandir hacia la izquierda
    int start = wordIndex;
    while (start > 0) {
      final char = fullText[start - 1];
      if (delimiters.hasMatch(char)) {
        break;
      }
      start--;
    }

    // Expandir hacia la derecha
    int end = wordEnd;
    while (end < fullText.length) {
      final char = fullText[end];
      if (delimiters.hasMatch(char)) {
        // Incluir puntuación pero no saltos de línea
        if (mode == ContextMode.sentence && char != '\n') {
          end++;
        }
        break;
      }
      end++;
    }

    // Extraer y limpiar
    String extracted = fullText.substring(start, end);
    return _cleanText(extracted);
  }

  /// Limpia el texto de referencias y espacios extra
  String _cleanText(String text) {
    var cleaned = text;

    // Eliminar referencias tipo [1], [12]
    cleaned = cleaned.replaceAll(RegExp(r'\[\d+\]'), '');

    // Reemplazar saltos de línea y tabulaciones por espacios
    cleaned = cleaned.replaceAll(RegExp(r'[\n\r\t]'), ' ');

    // Eliminar espacios múltiples
    cleaned = cleaned.replaceAll(RegExp(r'\s+'), ' ');

    // Eliminar espacios al inicio y final
    cleaned = cleaned.trim();

    // Eliminar puntuación final suelta
    cleaned = cleaned.replaceAll(RegExp(r'[:;,]+$'), '');

    return cleaned.trim();
  }
}
